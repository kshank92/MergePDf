﻿// ***********************************************************************
// Assembly         : CBI.MergePDF
// Author           : chaitan13552
// Created          : 03-23-2019
//
// Last Modified By : chaitan13552
// Last Modified On : 03-23-2019
// ***********************************************************************
// <copyright file="MergeMultiplePDF.cs" company="">
//     Copyright ©  2018
// </copyright>
// <summary></summary>
// ***********************************************************************
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;

namespace MergePDF
{
    /// <summary>
    /// Class MergeMultiplePDF.
    /// </summary>
    public class MergeMultiplePDF
    {
        #region Fields
        /// <summary>
        /// The sourcefolder
        /// </summary>
        private string sourcefolder;
        /// <summary>
        /// The destinationfile
        /// </summary>
        private string destinationfile;
        /// <summary>
        /// The file list
        /// </summary>
        private System.Collections.IList fileList = new ArrayList();
        #endregion

        //public MergeMultiplePDF(IList _fileList)
        //{
        //    this.fileList = _fileList;
        //}
        #region Public Methods
        ///
        /// Add a new file, together with a given docname to the fileList and namelist collection
        ///
        /// <summary>
        /// Adds the file.
        /// </summary>
        /// <param name="pathnname">The pathnname.</param>
        public void AddFile(string pathnname)
        {
            fileList.Add(pathnname);
        }

        ///
        /// Generate the merged PDF
        ///
        /// <summary>
        /// Executes this instance.
        /// </summary>
        public void Execute()
        {
            //MergeDocs();
        }
        #endregion

        #region Private Methods
        ///
        /// Merges the Docs and renders the destinationFile
        ///
       /* private void MergeDocs()
        {

            //Step 1: Create a Docuement-Object
            Document document = new Document();
            try
            {
                //Step 2: we create a writer that listens to the document
                PdfWriter writer = PdfWriter.GetInstance(document,
               new FileStream(destinationfile, FileMode.Create));

                //Step 3: Open the document
                document.Open();

                PdfContentByte cb = writer.DirectContent;
                PdfImportedPage page;

                int n = 0;
                int rotation = 0;



                //Loops for each file that has been listed
                foreach (string filename in fileList)
                {
                    //The current file path
                    //  string filePath = sourcefolder + filename; 

                    // we create a reader for the document
                    PdfReader reader = new PdfReader(filename);

                    //Gets the number of pages to process
                    n = reader.NumberOfPages;

                    int i = 0;
                    while (i < n)
                    {
                        i++;
                        document.SetPageSize(reader.GetPageSizeWithRotation(1));
                        document.NewPage();

                        //Insert to Destination on the first page
                        if (i == 1)
                        {
                            Chunk fileRef = new Chunk(" ");
                            fileRef.SetLocalDestination(filename);
                            document.Add(fileRef);
                        }

                        page = writer.GetImportedPage(reader, i);
                        rotation = reader.GetPageRotation(i);
                        if (rotation == 90 || rotation == 270)
                        {
                            cb.AddTemplate(page, 0, -1f, 1f, 0, 0,
                          reader.GetPageSizeWithRotation(i).Height);
                        }
                        else
                        {
                            cb.AddTemplate(page, 1f, 0, 0, 1f, 0, 0);
                        }
                    }
                }
            }
            catch (Exception e) { throw e; }
            finally { document.Close(); }
        }
        */
        #endregion

        ///
        /// Gets or Sets the DestinationFile
        ///
        /// <summary>
        /// Gets or sets the destination file.
        /// </summary>
        /// <value>The destination file.</value>
        public string DestinationFile
        {
            get { return destinationfile; }
            set { destinationfile = value; }
        }


        /// <summary>
        /// Merges the PDF files old.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="pdfFiles">The PDF files.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        /// <exception cref="System.Exception"></exception>
        public bool MergePdfFilesOld(string outputPath, string[] pdfFiles)
        {
            bool result = false;
            int pdfCount = 0; //total input pdf file count 
            int f = 0; //pointer to current input pdf file 
            string fileName = string.Empty; //current input pdf filename 
            iTextSharp.text.pdf.PdfReader reader = null;
            int pageCount = 0; //cureent input pdf page count 
            iTextSharp.text.Document pdfDoc = null;
            //the output pdf document        
            PdfWriter writer = null;
            PdfContentByte cb = null;
            //Declare a variable to hold the imported pages        
            PdfImportedPage page = null;
            int rotation = 0;
            //Declare a font to used for the bookmarks        
            iTextSharp.text.Font bookmarkFont = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.HELVETICA, 12, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLUE);
            try
            {
                pdfCount = pdfFiles.Length;
                if (pdfCount > 1)
                {
                    //Open the 1st pad using PdfReader object                
                    fileName = pdfFiles[f];
                    reader = new iTextSharp.text.pdf.PdfReader(fileName);
                    //Get page count                
                    pageCount = reader.NumberOfPages;
                    //Instantiate an new instance of pdf document and set its margins. This will be the output pdf.                
                    //NOTE: bookmarks will be added at the 1st page of very original pdf file using its filename. The location                
                    //of this bookmark will be placed at the upper left hand corner of the document. So you'll need to adjust                
                    //the margin left and margin top values such that the bookmark won't overlay on the merged pdf page. The                 
                    //unit used is "points" (72 points = 1 inch), thus in this example, the bookmarks' location is at 1/4 inch from                
                    //left and 1/4 inch from top of the page.                
                    pdfDoc = new iTextSharp.text.Document(reader.GetPageSizeWithRotation(1), 18, 18, 18, 18);
                    //Instantiate a PdfWriter that listens to the pdf document                
                    writer = PdfWriter.GetInstance(pdfDoc, new System.IO.FileStream(outputPath, System.IO.FileMode.Create));
                    //Set metadata and open the document                
                    pdfDoc.AddAuthor("Your name here");
                    pdfDoc.AddCreationDate();
                    pdfDoc.AddCreator("Your program name here");
                    pdfDoc.AddSubject("Whatever subject you want to give it");
                    //Use the filename as the title... You can give it any title of course.                    
                    pdfDoc.AddTitle(System.IO.Path.GetFileNameWithoutExtension(outputPath));
                    //Add keywords, whatever keywords you want to attach to it                    
                    pdfDoc.AddKeywords("Report, Merged PDF, " + System.IO.Path.GetFileName(outputPath));
                    pdfDoc.Open();
                    //Instantiate a PdfContentByte object                
                    cb = writer.DirectContent;
                    //Now loop thru the input pdfs      
                    int oldPageCount = 0;

                    while (f < pdfCount)
                    {
                        //Declare a page counter variable                    
                        int i = 0;
                        //Loop thru the current input pdf's pages starting at page 1                    
                        while (i < pageCount)
                        {

                            //First create a paragraph using the filename as the heading              
                            iTextSharp.text.Paragraph para = new iTextSharp.text.Paragraph();
                            //Then create a chapter from the above paragraph  
                            if (oldPageCount == 0)
                            {
                                int totalPages = 0;
                                for (int j = 0; j < pdfCount; j++)
                                {
                                    int localvar = 0;

                                    int pageCount1 = 0;
                                    if (j != 0)
                                    {
                                        //for (int k = 0; k < pdfCount; k++)
                                        //{
                                        string fileName1 = pdfFiles[j - 1];
                                        var reader1 = new iTextSharp.text.pdf.PdfReader(fileName1);
                                        //Get page count                
                                        pageCount1 += reader1.NumberOfPages;
                                        totalPages += pageCount1;
                                        // }

                                        localvar = totalPages;
                                    }
                                    else
                                    {
                                        localvar = 1;
                                    }


                                    Chunk chunk = new Chunk(pdfFiles[j].ToUpper(), bookmarkFont);

                                    PdfAction action = PdfAction.GotoLocalPage(localvar + 1, new PdfDestination(0), writer);
                                    chunk.SetAction(action);

                                    //Finally add the chapter to the document     

                                    para.Add(chunk);
                                    // chpter1.BookmarkOpen = true;
                                    //chpter1.Add(para1);

                                    pdfDoc.SetMargins(20f, 20f, 20f, 20f);
                                    pdfDoc.Add(para);

                                    oldPageCount++;
                                }
                            }



                            i += 1;

                            //Get the input page size                        
                            pdfDoc.SetPageSize(reader.GetPageSizeWithRotation(i));


                            //Create a new page on the output document                        
                            //pdfDoc.NewPage();


                            //Now we get the imported page                        
                            page = writer.GetImportedPage(reader, i);
                            //Read the imported page's rotation                        
                            rotation = reader.GetPageRotation(i);
                            //Then add the imported page to the PdfContentByte object as a template based on the page's rotation                        
                            if (rotation == 90)
                            {
                                cb.AddTemplate(page, 0, -1.0F, 1.0F, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                            }
                            else if (rotation == 270)
                            {
                                cb.AddTemplate(page, 0, 1.0F, -1.0F, 0, reader.GetPageSizeWithRotation(i).Width + 60, -30);
                            }
                            else
                            {
                                cb.AddTemplate(page, 1.0F, 0, 0, 1.0F, 0, 0);
                            }


                        }

                        //Increment f and read the next input pdf file                    
                        f += 1;
                        //if (f < pdfCount)
                        //{
                        //    fileName = pdfFiles[f];
                        //    reader = new iTextSharp.text.pdf.PdfReader(fileName);
                        //    pageCount = reader.NumberOfPages;
                        //}
                    }
                    //When all done, we close the documwent so that the pdfwriter object can write it to the output file                
                    pdfDoc.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                pdfDoc.Close();
                throw new Exception(ex.Message);
            }
            return result;
        }

        /// <summary>
        /// Merges the PDF files new.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="pdfFiles">The PDF files.</param>
        /// <returns>System.String.</returns>
        public string mergePdfFilesNew(string outputPath, string[] pdfFiles)
        {



            if (pdfFiles.Length > 0)
            {

                string path = MergeDocs(outputPath, pdfFiles);
                string reportName = pdfFiles[0];
                IList fileList = new ArrayList();
                fileList.Add(reportName);
                fileList.Add(path);


                //Step 1: Create a Docuement-Object
                Document document = new Document();
                try
                {
                    //Step 2: we create a writer that listens to the document
                    PdfWriter pdfwriter = PdfWriter.GetInstance(document,
                   new FileStream(outputPath, FileMode.Create));

                    //Step 3: Open the document
                    document.Open();

                    PdfContentByte pdfcb = pdfwriter.DirectContent;
                    PdfImportedPage page;

                    int n = 0;
                    int rotation = 0;

                    //Loops for each file that has been listed
                    foreach (string filename in fileList)
                    {
                        //The current file path
                        //  string filePath = sourcefolder + filename; 

                        // we create a reader for the document
                        PdfReader pdfreader = new PdfReader(filename);
                        renameFields(pdfreader);
                        //Gets the number of pages to process
                        n = pdfreader.NumberOfPages;

                        int i = 0;
                        while (i < n)
                        {
                            i++;
                            document.SetPageSize(pdfreader.GetPageSizeWithRotation(1));
                            document.NewPage();



                            page = pdfwriter.GetImportedPage(pdfreader, i);
                            rotation = pdfreader.GetPageRotation(i);
                            if (rotation == 90 || rotation == 270)
                            {
                                pdfcb.AddTemplate(page, 0, -1f, 1f, 0, 0,
                              pdfreader.GetPageSizeWithRotation(i).Height);
                            }
                            else
                            {
                                pdfcb.AddTemplate(page, 1f, 0, 0, 1f, 0, 0);
                            }
                        }
                    }
                }
                catch (Exception e) { throw e; }
                finally { document.Close(); }
            }
            return outputPath;
        }


        /// <summary>
        /// Merges the PDF files.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="pdfFiles">The PDF files.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        /// <exception cref="System.Exception"></exception>
        public bool MergePdfFiles(string outputPath, List<MergeDocument> pdfFiles)
        {
            bool result = false;
            int pdfCount = 0; //total input pdf file count 
            int f = 0; //pointer to current input pdf file 
            string fileName = string.Empty; //current input pdf filename 
            iTextSharp.text.pdf.PdfReader reader = null;
            int pageCount = 0; //cureent input pdf page count 
            iTextSharp.text.Document pdfDoc = null;
            //the output pdf document        
            PdfWriter writer = null;
            PdfContentByte cb = null;
            //Declare a variable to hold the imported pages        
            PdfImportedPage page = null;
            int rotation = 0;
            string fileExtention = ".pdf";
            //Declare a font to used for the bookmarks        
            iTextSharp.text.Font bookmarkFont = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.HELVETICA, 12, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLUE);
            try
            {
                pdfCount = pdfFiles.Count;
                if (pdfCount > 1)
                {
                    //Open the 1st pad using PdfReader object                
                    fileName = pdfFiles[0].DocumentName;
                    reader = new iTextSharp.text.pdf.PdfReader(fileName);
                    //Get page count                
                    pageCount = reader.NumberOfPages;
                    //Instantiate an new instance of pdf document and set its margins. This will be the output pdf.                
                    //NOTE: bookmarks will be added at the 1st page of very original pdf file using its filename. The location                
                    //of this bookmark will be placed at the upper left hand corner of the document. So you'll need to adjust                
                    //the margin left and margin top values such that the bookmark won't overlay on the merged pdf page. The                 
                    //unit used is "points" (72 points = 1 inch), thus in this example, the bookmarks' location is at 1/4 inch from                
                    //left and 1/4 inch from top of the page.                
                    pdfDoc = new iTextSharp.text.Document(reader.GetPageSizeWithRotation(1), 18, 18, 18, 18);
                    //Instantiate a PdfWriter that listens to the pdf document                
                    writer = PdfWriter.GetInstance(pdfDoc, new System.IO.FileStream(outputPath, System.IO.FileMode.Create));
                    //Set metadata and open the document                
                    pdfDoc.AddAuthor("Your name here");
                    pdfDoc.AddCreationDate();
                    pdfDoc.AddCreator("Your program name here");
                    pdfDoc.AddSubject("Whatever subject you want to give it");
                    //Use the filename as the title... You can give it any title of course.                    
                    pdfDoc.AddTitle(System.IO.Path.GetFileNameWithoutExtension(outputPath));
                    //Add keywords, whatever keywords you want to attach to it                    
                    pdfDoc.AddKeywords("Report, Merged PDF, " + System.IO.Path.GetFileName(outputPath));
                    pdfDoc.Open();
                    //Instantiate a PdfContentByte object                
                    cb = writer.DirectContent;
                    //Now loop thru the input pdfs      
                    int oldPageCount = 0;


                    //string fileName2 = pdfFiles[0].DocumentName;
                    //var reader2 = new iTextSharp.text.pdf.PdfReader(fileName2);
                    ////Get page count                
                    //var pageCount2 = reader2.NumberOfPages + 1;
                    while (f < pdfCount)
                    {


                        //Declare a page counter variable                    
                        int i = 0;
                        //Loop thru the current input pdf's pages starting at page 1                    
                        while (i < pageCount)
                        {


                            //First create a paragraph using the filename as the heading              
                            iTextSharp.text.Paragraph para = new iTextSharp.text.Paragraph();
                            //Then create a chapter from the above paragraph  
                            //if (f == 1 && oldPageCount == 0)
                            //{


                            //    Chunk chunk1 = new Chunk("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
                            //    iTextSharp.text.Paragraph p = new iTextSharp.text.Paragraph();
                            //    p.Add(chunk1);
                            //    pdfDoc.Add(p);

                            //    //Get the input page size                        
                            //    // pdfDoc.SetPageSize(PageSize.A4);

                            //    //Create a new page on the output document                        
                            //    pdfDoc.NewPage();


                            //    int totalPages = 0;
                            //    for (int j = 0; j < pdfCount; j++)
                            //    {
                            //        int localvar = 0;

                            //        int pageCount1 = 0;
                            //        string otherDocName = pdfFiles[j].DocumentURL;
                            //        string fileExtn = Path.GetExtension(otherDocName);
                            //        if (fileExtn != ".pdf" && fileExtn != ".PDF")
                            //        {



                            //            Chunk chunk = new Chunk(pdfFiles[j].DocumentName.ToUpper(), bookmarkFont);

                            //            chunk.SetAnchor(pdfFiles[j].DocumentName.ToUpper());

                            //            para.Add(chunk);
                            //            // chpter1.BookmarkOpen = true;
                            //            //chpter1.Add(para1);

                            //            pdfDoc.SetMargins(20f, 20f, 20f, 20f);
                            //            pdfDoc.Add(para);

                            //        }
                            //        else
                            //        {
                            //            if (j != 0)
                            //            {
                            //                //for (int k = 0; k < pdfCount; k++)
                            //                //{
                            //                string fileName1 = pdfFiles[j].DocumentURL;


                            //                var reader1 = new iTextSharp.text.pdf.PdfReader(fileName1);
                            //                //Get page count                
                            //                pageCount1 += reader1.NumberOfPages;
                            //                totalPages += pageCount1;
                            //                // }

                            //                localvar = totalPages;

                            //            }
                            //            else
                            //            {
                            //                localvar = 1;
                            //            }

                            //            Chunk chunk = new Chunk(pdfFiles[j].DocumentName.ToUpper(), bookmarkFont);

                            //            PdfAction action = PdfAction.GotoLocalPage(localvar + 2, new PdfDestination(0), writer);
                            //            chunk.SetAction(action);

                            //            //Finally add the chapter to the document     

                            //            para.Add(chunk);
                            //            // chpter1.BookmarkOpen = true;
                            //            //chpter1.Add(para1);

                            //            pdfDoc.SetMargins(20f, 20f, 20f, 20f);
                            //            pdfDoc.Add(para);


                            //        }
                            //        oldPageCount++;
                            //    }


                            //}

                            i += 1;
                            if (fileExtention == ".pdf" || fileExtention == ".PDF")
                            {


                                //Get the input page size                        
                                pdfDoc.SetPageSize(reader.GetPageSizeWithRotation(i));


                                //Create a new page on the output document                        
                                pdfDoc.NewPage();



                                //Now we get the imported page                        
                                page = writer.GetImportedPage(reader, i);

                                //PdfCopy copy = new PdfCopy(new PdfDocument(), new FileStream(outputPath, FileMode.Create));
                                //copy.AddDocument(reader);
                                //cb = copy.DirectContent;

                                //Read the imported page's rotation                        
                                rotation = reader.GetPageRotation(i);
                                //Then add the imported page to the PdfContentByte object as a template based on the page's rotation                        
                                if (rotation == 90)
                                {
                                    cb.AddTemplate(page, 0, -1.0F, 1.0F, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                                }
                                else if (rotation == 270)
                                {
                                    cb.AddTemplate(page, 0, 1.0F, -1.0F, 0, reader.GetPageSizeWithRotation(i).Width + 60, -30);
                                }
                                else
                                {
                                    cb.AddTemplate(page, 1.0F, 0, 0, 1.0F, 0, 0);
                                }

                            }
                            //else
                            //{                                
                            //    using (StreamReader rdr = new StreamReader(pdfFiles[f].DocumentURL.ToUpper()))
                            //    {
                            //        pdfDoc.NewPage();
                            //        //Add the content of Text File to PDF File
                            //        pdfDoc.Add(new Paragraph(rdr.ReadToEnd().ToString()));
                            //    }
                            //}
                        }


                        //Increment f and read the next input pdf file                    
                        f += 1;
                        if (f < pdfCount)
                        {
                            fileName = pdfFiles[f].DocumentURL;
                            fileExtention = Path.GetExtension(fileName);
                            if (fileExtention == ".pdf" || fileExtention == ".PDF")
                            {
                                reader = new iTextSharp.text.pdf.PdfReader(fileName);
                                pageCount = reader.NumberOfPages;
                            }
                            else
                                pageCount = 0;
                        }
                    }
                    //When all done, we close the documwent so that the pdfwriter object can write it to the output file                
                    pdfDoc.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message);
            }
            finally { pdfDoc.Close(); }
            return result;
        }

        public bool MergePDFsImproved(string mergedFile, List<string> files)
        {
            bool mergeSucceeded;
            try
            {
                using (FileStream mem = new FileStream(mergedFile, FileMode.Create))
                {
                    List<PdfReader> readers = new List<PdfReader>();
                    using (Document doc = new Document())
                    {
                        PdfCopy copy = new PdfCopy(doc, mem);
                        copy.SetMergeFields();
                        doc.Open();
                        foreach (string strfile in files)
                        {

                            string fileExtention = Path.GetExtension(strfile);
                            if (fileExtention.ToLower() == ".pdf")
                            {
                                PdfReader reader = new PdfReader(strfile);
                                copy.AddDocument(reader);
                                readers.Add(reader);
                            }
                        }
                    }
                    foreach (PdfReader reader in readers)
                        reader.Close();
                }
                mergeSucceeded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return mergeSucceeded;
        }


        /// <summary>
        /// Gets the extension.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        private string GetExtension(string fileName)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// The counter
        /// </summary>
        private static int counter = 0;
        /// <summary>
        /// Renames the fields.
        /// </summary>
        /// <param name="pdfReader">The PDF reader.</param>
        private void renameFields(PdfReader pdfReader)
        {
            try
            {
                string prepend = String.Format("_{0}", counter++);
                foreach (var de in pdfReader.AcroFields.Fields)
                {
                    pdfReader.AcroFields.RenameField(de.Key.ToString(), prepend + de.Key.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Merges the docs.
        /// </summary>
        /// <param name="outputPath">The output path.</param>
        /// <param name="pdfFiles">The PDF files.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.Exception"></exception>
        private string MergeDocs(string outputPath, string[] pdfFiles)
        {
            bool result = false;
            int pdfCount = 0; //total input pdf file count 
            int f = 1; //pointer to current input pdf file 
            string fileName = string.Empty; //current input pdf filename 
            iTextSharp.text.pdf.PdfReader reader = null;
            int pageCount = 0; //cureent input pdf page count 
            iTextSharp.text.Document pdfDoc = null;
            //the output pdf document        
            PdfWriter writer = null;
            PdfContentByte cb = null;
            //Declare a variable to hold the imported pages        
            PdfImportedPage page = null;
            int rotation = 0;
            //Declare a font to used for the bookmarks        
            iTextSharp.text.Font bookmarkFont = iTextSharp.text.FontFactory.GetFont(iTextSharp.text.FontFactory.HELVETICA, 12, iTextSharp.text.Font.BOLD, iTextSharp.text.BaseColor.BLUE);
            try
            {
                pdfCount = pdfFiles.Length;
                if (pdfCount > 1)
                {
                    //Open the 1st pad using PdfReader object                
                    fileName = pdfFiles[f];
                    reader = new iTextSharp.text.pdf.PdfReader(fileName);

                    renameFields(reader);
                    //Get page count                
                    pageCount = reader.NumberOfPages;
                    //Instantiate an new instance of pdf document and set its margins. This will be the output pdf.                
                    //NOTE: bookmarks will be added at the 1st page of very original pdf file using its filename. The location                
                    //of this bookmark will be placed at the upper left hand corner of the document. So you'll need to adjust                
                    //the margin left and margin top values such that the bookmark won't overlay on the merged pdf page. The                 
                    //unit used is "points" (72 points = 1 inch), thus in this example, the bookmarks' location is at 1/4 inch from                
                    //left and 1/4 inch from top of the page.                
                    pdfDoc = new iTextSharp.text.Document(reader.GetPageSizeWithRotation(1), 18, 18, 18, 18);
                    //Instantiate a PdfWriter that listens to the pdf document                
                    writer = PdfWriter.GetInstance(pdfDoc, new System.IO.FileStream(outputPath, System.IO.FileMode.Create));
                    //Set metadata and open the document                
                    pdfDoc.AddAuthor("Your name here");
                    pdfDoc.AddCreationDate();
                    pdfDoc.AddCreator("Your program name here");
                    pdfDoc.AddSubject("Whatever subject you want to give it");
                    //Use the filename as the title... You can give it any title of course.                    
                    pdfDoc.AddTitle(System.IO.Path.GetFileNameWithoutExtension(outputPath));
                    //Add keywords, whatever keywords you want to attach to it                    
                    pdfDoc.AddKeywords("Report, Merged PDF, " + System.IO.Path.GetFileName(outputPath));
                    pdfDoc.Open();
                    //Instantiate a PdfContentByte object                
                    cb = writer.DirectContent;
                    //Now loop thru the input pdfs      
                    int oldPageCount = 0;

                    while (f < pdfCount)
                    {
                        //Declare a page counter variable                    
                        int i = 0;
                        //Loop thru the current input pdf's pages starting at page 1                    
                        while (i < pageCount)
                        {

                            //First create a paragraph using the filename as the heading              
                            iTextSharp.text.Paragraph para = new iTextSharp.text.Paragraph();
                            //Then create a chapter from the above paragraph  
                            if (oldPageCount == 0)
                            {
                                int totalPages = 0;
                                for (int j = 0; j < pdfCount; j++)
                                {
                                    int localvar = 0;

                                    int pageCount1 = 0;
                                    if (j != 0)
                                    {
                                        //for (int k = 0; k < pdfCount; k++)
                                        //{
                                        string fileName1 = pdfFiles[j];
                                        var reader1 = new iTextSharp.text.pdf.PdfReader(fileName1);
                                        //Get page count                
                                        pageCount1 += reader1.NumberOfPages;
                                        totalPages += pageCount1;
                                        // }

                                        localvar = totalPages;
                                    }
                                    else
                                    {
                                        localvar = 1;
                                    }


                                    Chunk chunk = new Chunk(pdfFiles[j].ToUpper(), bookmarkFont);

                                    PdfAction action = PdfAction.GotoLocalPage(localvar + 1, new PdfDestination(0), writer);
                                    chunk.SetAction(action);

                                    //Finally add the chapter to the document     

                                    para.Add(chunk);
                                    // chpter1.BookmarkOpen = true;
                                    //chpter1.Add(para1);

                                    pdfDoc.SetMargins(20f, 20f, 20f, 20f);
                                    pdfDoc.Add(para);

                                    oldPageCount++;
                                }
                            }



                            i += 1;

                            //Get the input page size                        
                            pdfDoc.SetPageSize(reader.GetPageSizeWithRotation(i));


                            //Create a new page on the output document                        
                            pdfDoc.NewPage();


                            //Now we get the imported page                        
                            page = writer.GetImportedPage(reader, i);
                            //Read the imported page's rotation                        
                            rotation = reader.GetPageRotation(i);
                            //Then add the imported page to the PdfContentByte object as a template based on the page's rotation                        
                            if (rotation == 90)
                            {
                                cb.AddTemplate(page, 0, -1.0F, 1.0F, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                            }
                            else if (rotation == 270)
                            {
                                cb.AddTemplate(page, 0, 1.0F, -1.0F, 0, reader.GetPageSizeWithRotation(i).Width + 60, -30);
                            }
                            else
                            {
                                cb.AddTemplate(page, 1.0F, 0, 0, 1.0F, 0, 0);
                            }


                        }

                        //Increment f and read the next input pdf file                    
                        f += 1;
                        if (f < pdfCount)
                        {
                            fileName = pdfFiles[f];
                            reader = new iTextSharp.text.pdf.PdfReader(fileName);
                            pageCount = reader.NumberOfPages;
                        }
                    }
                    //When all done, we close the documwent so that the pdfwriter object can write it to the output file                
                    pdfDoc.Close();
                    result = true;
                }
            }
            catch (Exception ex)
            {
                pdfDoc.Close();
                throw new Exception(ex.Message);
            }
            if (result)
            {
                return outputPath;
            }
            else
            {
                return "";
            }
        }



        /// <summary>
        /// Converts the image to PDF.
        /// </summary>
        /// <param name="srcFilename">The source filename.</param>
        /// <param name="dstFilename">The DST filename.</param>
        /// <returns>System.String.</returns>
        public string ConvertImageToPdf(string srcFilename, string dstFilename)
        {
            iTextSharp.text.Rectangle pageSize = null;

            using (var srcImage = new Bitmap(srcFilename))
            {
                pageSize = new iTextSharp.text.Rectangle(0, 0, srcImage.Width, srcImage.Height);
            }
            using (var ms = new MemoryStream())
            {
                var document = new iTextSharp.text.Document(pageSize, 0, 0, 0, 0);
                iTextSharp.text.pdf.PdfWriter.GetInstance(document, ms).SetFullCompression();
                document.Open();
                var image = iTextSharp.text.Image.GetInstance(srcFilename);
                document.Add(image);
                document.Close();

                File.WriteAllBytes(dstFilename, ms.ToArray());
            }
            return dstFilename;
        }

        /// <summary>
        /// Converts the word to PDF.
        /// </summary>
        /// <param name="srcFilename">The source filename.</param>
        /// <param name="dstFilename">The DST filename.</param>
        public void ConvertWordToPDF(string srcFilename, string dstFilename)
        {
            //Read the Data from Input File

            StreamReader rdr = new StreamReader(srcFilename);

            //Create a New instance on Document Class

            Document doc = new Document();

            //Create a New instance of PDFWriter Class for Output File

            PdfWriter.GetInstance(doc, new FileStream(dstFilename, FileMode.Create));

            //Open the Document

            doc.Open();

            //Add the content of Text File to PDF File

            doc.Add(new Paragraph(rdr.ReadToEnd()));

            //Close the Document

            doc.Close();
        }


        //public byte[] MergeFilesAndAddBookmarks(Dictionary<PrintDocument, byte[]> sourceFiles)
        //{
        //    using (var ms = new MemoryStream())
        //    {
        //        using (var document = new Document())
        //        {
        //            using (var copy = new PdfCopy(document, ms))
        //            {
        //                //Order the files by chapternumber
        //                var files = sourceFiles.GroupBy(f => f.Key.ChapterNumber);

        //                document.Open();

        //                var outlines = new List<Dictionary<string, object>>();

        //                var pageIndex = 1;

        //                foreach (var chapterGroup in files)
        //                {
        //                    var map = new Dictionary<string, object>();
        //                    outlines.Add(map);
        //                    map.Add("Title", chapterGroup.First().Key.ChapterName);
        //                    var kids = new List<Dictionary<string, object>>();
        //                    map.Add("Kids", kids);

        //                    foreach (var sourceFile in chapterGroup)
        //                    {
        //                        using (var reader = new PdfReader(sourceFile.Value))
        //                        {
        //                            // add the pages
        //                            var n = reader.NumberOfPages;

        //                            for (var page = 0; page < n;)
        //                            {
        //                                if (page == 0)
        //                                {
        //                                    var kid = new Dictionary<string, object>();
        //                                    kids.Add(kid);
        //                                    kid["Title"] = sourceFile.Key.Title;
        //                                    kid["Action"] = "GoTo";
        //                                    kid["Page"] = String.Format("{0} Fit", pageIndex);
        //                                }
        //                                copy.AddPage(copy.GetImportedPage(reader, ++page));
        //                            }

        //                            pageIndex += n;
        //                            reader.Close();
        //                        }
        //                    }
        //                }

        //                copy.Outlines = outlines;
        //                document.Close();
        //                copy.Close();
        //                ms.Close();
        //            }
        //        }
        //        return ms.ToArray();
        //    }
        //}
    }

    /// <summary>
    /// Class MergeDocument.
    /// </summary>
    public class MergeDocument
    {
        /// <summary>
        /// Gets or sets the name of the document.
        /// </summary>
        /// <value>The name of the document.</value>
        public string DocumentName { get; set; }
        /// <summary>
        /// Gets or sets the document URL.
        /// </summary>
        /// <value>The document URL.</value>
        public string DocumentURL { get; set; }

    }

}


